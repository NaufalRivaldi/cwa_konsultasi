<section id="footer">
	<div class="container">
		<div class="row">
			<div class="col-md">
				<p class="text-footer">Copyright © Citra Warna 2019</p>	
			</div>
		</div>
	</div>
</section>